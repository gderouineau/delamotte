jQuery(window).load(function() { 
"use strict";
			jQuery("#status").fadeOut(350); // will first fade out the loading animation
			jQuery("#preloader").delay(350).fadeOut(200); // will fade out the white DIV that covers the website.
		})
